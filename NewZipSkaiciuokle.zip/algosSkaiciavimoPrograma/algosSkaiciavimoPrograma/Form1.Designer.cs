﻿namespace algosSkaiciavimoPrograma
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox22proc = new System.Windows.Forms.CheckBox();
            this.checkBox19proc = new System.Windows.Forms.CheckBox();
            this.label2kokes2 = new System.Windows.Forms.Label();
            this.checkBox10proc = new System.Windows.Forms.CheckBox();
            this.txtboxAlgiRank1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtboxdarbdavMokesc1 = new System.Windows.Forms.TextBox();
            this.txtBoxSodramok1 = new System.Windows.Forms.TextBox();
            this.txtboxPajammokes1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtBoxVardas1 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.txtboxAlgAntPop1 = new System.Windows.Forms.TextBox();
            this.txtboxvisoMokesc1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox22proc1 = new System.Windows.Forms.CheckBox();
            this.checkBox19proc1 = new System.Windows.Forms.CheckBox();
            this.checkBox10proc1 = new System.Windows.Forms.CheckBox();
            this.Label1mokes = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxtab1 = new System.Windows.Forms.TextBox();
            this.checkBoxPasirkt1 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.darbdMokesc = new System.Windows.Forms.TextBox();
            this.sodrosMokes = new System.Windows.Forms.TextBox();
            this.pajamuMokest = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.empName = new System.Windows.Forms.TextBox();
            this.iseitiBtn = new System.Windows.Forms.Button();
            this.trintiBtn = new System.Windows.Forms.Button();
            this.skaiciuotiBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.algaiRankas = new System.Windows.Forms.TextBox();
            this.taxdeductbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.algaAntPop = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(824, 453);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightSlateGray;
            this.groupBox2.Controls.Add(this.checkBox22proc);
            this.groupBox2.Controls.Add(this.checkBox19proc);
            this.groupBox2.Controls.Add(this.label2kokes2);
            this.groupBox2.Controls.Add(this.checkBox10proc);
            this.groupBox2.Controls.Add(this.txtboxAlgiRank1);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtboxdarbdavMokesc1);
            this.groupBox2.Controls.Add(this.txtBoxSodramok1);
            this.groupBox2.Controls.Add(this.txtboxPajammokes1);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtBoxVardas1);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtboxAlgAntPop1);
            this.groupBox2.Controls.Add(this.txtboxvisoMokesc1);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(-4, -1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(832, 464);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Atlyginimo skaiciuokle ant popieriaus";
            // 
            // checkBox22proc
            // 
            this.checkBox22proc.AutoSize = true;
            this.checkBox22proc.Location = new System.Drawing.Point(191, 187);
            this.checkBox22proc.Name = "checkBox22proc";
            this.checkBox22proc.Size = new System.Drawing.Size(51, 22);
            this.checkBox22proc.TabIndex = 24;
            this.checkBox22proc.Text = "22%";
            this.checkBox22proc.UseVisualStyleBackColor = true;
            this.checkBox22proc.Visible = false;
            // 
            // checkBox19proc
            // 
            this.checkBox19proc.AutoSize = true;
            this.checkBox19proc.Location = new System.Drawing.Point(111, 187);
            this.checkBox19proc.Name = "checkBox19proc";
            this.checkBox19proc.Size = new System.Drawing.Size(51, 22);
            this.checkBox19proc.TabIndex = 23;
            this.checkBox19proc.Text = "19%";
            this.checkBox19proc.UseVisualStyleBackColor = true;
            this.checkBox19proc.Visible = false;
            // 
            // label2kokes2
            // 
            this.label2kokes2.AutoSize = true;
            this.label2kokes2.Location = new System.Drawing.Point(8, 156);
            this.label2kokes2.Name = "label2kokes2";
            this.label2kokes2.Size = new System.Drawing.Size(274, 18);
            this.label2kokes2.TabIndex = 22;
            this.label2kokes2.Text = "Pasirinkite kiek mokesciu mokesite:";
            this.label2kokes2.Visible = false;
            // 
            // checkBox10proc
            // 
            this.checkBox10proc.AutoSize = true;
            this.checkBox10proc.Location = new System.Drawing.Point(17, 187);
            this.checkBox10proc.Name = "checkBox10proc";
            this.checkBox10proc.Size = new System.Drawing.Size(51, 22);
            this.checkBox10proc.TabIndex = 21;
            this.checkBox10proc.Text = "10%";
            this.checkBox10proc.UseVisualStyleBackColor = true;
            this.checkBox10proc.Visible = false;
            // 
            // txtboxAlgiRank1
            // 
            this.txtboxAlgiRank1.Location = new System.Drawing.Point(237, 72);
            this.txtboxAlgiRank1.Name = "txtboxAlgiRank1";
            this.txtboxAlgiRank1.Size = new System.Drawing.Size(126, 25);
            this.txtboxAlgiRank1.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(4, 232);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(338, 25);
            this.label9.TabIndex = 19;
            this.label9.Text = "Jusu sumokami mokesciai bus:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(286, 120);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(77, 25);
            this.textBox2.TabIndex = 18;
            this.textBox2.Visible = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(17, 120);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(253, 22);
            this.checkBox2.TabIndex = 17;
            this.checkBox2.Text = "Pajamos per autorines sutartis";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(8, 423);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(282, 21);
            this.label10.TabIndex = 16;
            this.label10.Text = "Darbdavio mokesciai uz zmogu:";
            // 
            // txtboxdarbdavMokesc1
            // 
            this.txtboxdarbdavMokesc1.Location = new System.Drawing.Point(296, 423);
            this.txtboxdarbdavMokesc1.Name = "txtboxdarbdavMokesc1";
            this.txtboxdarbdavMokesc1.Size = new System.Drawing.Size(93, 25);
            this.txtboxdarbdavMokesc1.TabIndex = 15;
            // 
            // txtBoxSodramok1
            // 
            this.txtBoxSodramok1.Location = new System.Drawing.Point(168, 276);
            this.txtBoxSodramok1.Name = "txtBoxSodramok1";
            this.txtBoxSodramok1.Size = new System.Drawing.Size(74, 25);
            this.txtBoxSodramok1.TabIndex = 14;
            // 
            // txtboxPajammokes1
            // 
            this.txtboxPajammokes1.Location = new System.Drawing.Point(168, 317);
            this.txtboxPajammokes1.Name = "txtboxPajammokes1";
            this.txtboxPajammokes1.Size = new System.Drawing.Size(74, 25);
            this.txtboxPajammokes1.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(7, 278);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(155, 20);
            this.label11.TabIndex = 12;
            this.label11.Text = "Sodros mokesciai:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(5, 317);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(149, 20);
            this.label12.TabIndex = 11;
            this.label12.Text = "Pajamu mokestis:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 33);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(205, 18);
            this.label13.TabIndex = 10;
            this.label13.Text = "Iveskite darbininko varda:";
            // 
            // txtBoxVardas1
            // 
            this.txtBoxVardas1.Location = new System.Drawing.Point(237, 26);
            this.txtBoxVardas1.Name = "txtBoxVardas1";
            this.txtBoxVardas1.Size = new System.Drawing.Size(126, 25);
            this.txtBoxVardas1.TabIndex = 9;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(708, 224);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 45);
            this.button4.TabIndex = 8;
            this.button4.Text = "Iseiti";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(708, 120);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 44);
            this.button5.TabIndex = 7;
            this.button5.Text = "Trinti";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(708, 30);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(100, 43);
            this.button6.TabIndex = 6;
            this.button6.Text = "Skaiciuoti";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(403, 385);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(299, 29);
            this.label14.TabIndex = 5;
            this.label14.Text = "Alga ant popieriaus bus:";
            // 
            // txtboxAlgAntPop1
            // 
            this.txtboxAlgAntPop1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxAlgAntPop1.Location = new System.Drawing.Point(708, 385);
            this.txtboxAlgAntPop1.Name = "txtboxAlgAntPop1";
            this.txtboxAlgAntPop1.Size = new System.Drawing.Size(114, 31);
            this.txtboxAlgAntPop1.TabIndex = 4;
            // 
            // txtboxvisoMokesc1
            // 
            this.txtboxvisoMokesc1.Location = new System.Drawing.Point(168, 358);
            this.txtboxvisoMokesc1.Name = "txtboxvisoMokesc1";
            this.txtboxvisoMokesc1.Size = new System.Drawing.Size(74, 25);
            this.txtboxvisoMokesc1.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 365);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(140, 18);
            this.label15.TabIndex = 2;
            this.label15.Text = "Moskeciai is viso:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 75);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(174, 18);
            this.label16.TabIndex = 1;
            this.label16.Text = "Iveskite alga i rankas:";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(824, 453);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightSlateGray;
            this.groupBox1.Controls.Add(this.checkBox22proc1);
            this.groupBox1.Controls.Add(this.checkBox19proc1);
            this.groupBox1.Controls.Add(this.checkBox10proc1);
            this.groupBox1.Controls.Add(this.Label1mokes);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBoxtab1);
            this.groupBox1.Controls.Add(this.checkBoxPasirkt1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.darbdMokesc);
            this.groupBox1.Controls.Add(this.sodrosMokes);
            this.groupBox1.Controls.Add(this.pajamuMokest);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.empName);
            this.groupBox1.Controls.Add(this.iseitiBtn);
            this.groupBox1.Controls.Add(this.trintiBtn);
            this.groupBox1.Controls.Add(this.skaiciuotiBtn);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.algaiRankas);
            this.groupBox1.Controls.Add(this.taxdeductbox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.algaAntPop);
            this.groupBox1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(-4, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(832, 457);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Atlyginimo skaiciuokle i rankas";
            // 
            // checkBox22proc1
            // 
            this.checkBox22proc1.AutoSize = true;
            this.checkBox22proc1.Location = new System.Drawing.Point(200, 186);
            this.checkBox22proc1.Name = "checkBox22proc1";
            this.checkBox22proc1.Size = new System.Drawing.Size(51, 22);
            this.checkBox22proc1.TabIndex = 26;
            this.checkBox22proc1.Text = "22%";
            this.checkBox22proc1.UseVisualStyleBackColor = true;
            this.checkBox22proc1.Visible = false;
            // 
            // checkBox19proc1
            // 
            this.checkBox19proc1.AutoSize = true;
            this.checkBox19proc1.Location = new System.Drawing.Point(103, 186);
            this.checkBox19proc1.Name = "checkBox19proc1";
            this.checkBox19proc1.Size = new System.Drawing.Size(51, 22);
            this.checkBox19proc1.TabIndex = 25;
            this.checkBox19proc1.Text = "19%";
            this.checkBox19proc1.UseVisualStyleBackColor = true;
            this.checkBox19proc1.Visible = false;
            // 
            // checkBox10proc1
            // 
            this.checkBox10proc1.AutoSize = true;
            this.checkBox10proc1.Location = new System.Drawing.Point(17, 186);
            this.checkBox10proc1.Name = "checkBox10proc1";
            this.checkBox10proc1.Size = new System.Drawing.Size(51, 22);
            this.checkBox10proc1.TabIndex = 24;
            this.checkBox10proc1.Text = "10%";
            this.checkBox10proc1.UseVisualStyleBackColor = true;
            this.checkBox10proc1.Visible = false;
            this.checkBox10proc1.CheckedChanged += new System.EventHandler(this.checkBox10proc1_CheckedChanged);
            // 
            // Label1mokes
            // 
            this.Label1mokes.AutoSize = true;
            this.Label1mokes.Location = new System.Drawing.Point(14, 161);
            this.Label1mokes.Name = "Label1mokes";
            this.Label1mokes.Size = new System.Drawing.Size(274, 18);
            this.Label1mokes.TabIndex = 23;
            this.Label1mokes.Text = "Pasirinkite kiek mokesciu mokesite:";
            this.Label1mokes.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 233);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(338, 25);
            this.label8.TabIndex = 19;
            this.label8.Text = "Jusu sumokami mokesciai bus:";
            // 
            // textBoxtab1
            // 
            this.textBoxtab1.Location = new System.Drawing.Point(286, 120);
            this.textBoxtab1.Name = "textBoxtab1";
            this.textBoxtab1.Size = new System.Drawing.Size(77, 25);
            this.textBoxtab1.TabIndex = 18;
            this.textBoxtab1.Visible = false;
            // 
            // checkBoxPasirkt1
            // 
            this.checkBoxPasirkt1.AutoSize = true;
            this.checkBoxPasirkt1.Location = new System.Drawing.Point(17, 120);
            this.checkBoxPasirkt1.Name = "checkBoxPasirkt1";
            this.checkBoxPasirkt1.Size = new System.Drawing.Size(253, 22);
            this.checkBoxPasirkt1.TabIndex = 17;
            this.checkBoxPasirkt1.Text = "Pajamos per autorines sutartis";
            this.checkBoxPasirkt1.UseVisualStyleBackColor = true;
            this.checkBoxPasirkt1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 421);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(282, 21);
            this.label7.TabIndex = 16;
            this.label7.Text = "Darbdavio mokesciai uz zmogu:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // darbdMokesc
            // 
            this.darbdMokesc.Location = new System.Drawing.Point(295, 418);
            this.darbdMokesc.Name = "darbdMokesc";
            this.darbdMokesc.Size = new System.Drawing.Size(93, 25);
            this.darbdMokesc.TabIndex = 15;
            // 
            // sodrosMokes
            // 
            this.sodrosMokes.Location = new System.Drawing.Point(160, 268);
            this.sodrosMokes.Name = "sodrosMokes";
            this.sodrosMokes.Size = new System.Drawing.Size(74, 25);
            this.sodrosMokes.TabIndex = 14;
            // 
            // pajamuMokest
            // 
            this.pajamuMokest.Location = new System.Drawing.Point(160, 305);
            this.pajamuMokest.Name = "pajamuMokest";
            this.pajamuMokest.Size = new System.Drawing.Size(74, 25);
            this.pajamuMokest.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 273);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Sodros mokesciai:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 310);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Pajamu mokestis:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(205, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Iveskite darbininko varda:";
            // 
            // empName
            // 
            this.empName.Location = new System.Drawing.Point(246, 30);
            this.empName.Name = "empName";
            this.empName.Size = new System.Drawing.Size(117, 25);
            this.empName.TabIndex = 9;
            // 
            // iseitiBtn
            // 
            this.iseitiBtn.Location = new System.Drawing.Point(707, 186);
            this.iseitiBtn.Name = "iseitiBtn";
            this.iseitiBtn.Size = new System.Drawing.Size(100, 45);
            this.iseitiBtn.TabIndex = 8;
            this.iseitiBtn.Text = "Iseiti";
            this.iseitiBtn.UseVisualStyleBackColor = true;
            this.iseitiBtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // trintiBtn
            // 
            this.trintiBtn.Location = new System.Drawing.Point(707, 108);
            this.trintiBtn.Name = "trintiBtn";
            this.trintiBtn.Size = new System.Drawing.Size(100, 44);
            this.trintiBtn.TabIndex = 7;
            this.trintiBtn.Text = "Trinti";
            this.trintiBtn.UseVisualStyleBackColor = true;
            this.trintiBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // skaiciuotiBtn
            // 
            this.skaiciuotiBtn.Location = new System.Drawing.Point(707, 24);
            this.skaiciuotiBtn.Name = "skaiciuotiBtn";
            this.skaiciuotiBtn.Size = new System.Drawing.Size(100, 43);
            this.skaiciuotiBtn.TabIndex = 6;
            this.skaiciuotiBtn.Text = "Skaiciuoti";
            this.skaiciuotiBtn.UseVisualStyleBackColor = true;
            this.skaiciuotiBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(441, 378);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(226, 29);
            this.label3.TabIndex = 5;
            this.label3.Text = "Alga i rankas bus:";
            // 
            // algaiRankas
            // 
            this.algaiRankas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.algaiRankas.Location = new System.Drawing.Point(673, 378);
            this.algaiRankas.Name = "algaiRankas";
            this.algaiRankas.Size = new System.Drawing.Size(114, 31);
            this.algaiRankas.TabIndex = 4;
            // 
            // taxdeductbox
            // 
            this.taxdeductbox.Location = new System.Drawing.Point(160, 348);
            this.taxdeductbox.Name = "taxdeductbox";
            this.taxdeductbox.Size = new System.Drawing.Size(74, 25);
            this.taxdeductbox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 351);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Moskeciai is viso:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Iveskite alga ant popieriaus:";
            // 
            // algaAntPop
            // 
            this.algaAntPop.Location = new System.Drawing.Point(246, 75);
            this.algaAntPop.Name = "algaAntPop";
            this.algaAntPop.Size = new System.Drawing.Size(117, 25);
            this.algaAntPop.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(36, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(832, 479);
            this.tabControl1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1284, 612);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtboxAlgiRank1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtboxdarbdavMokesc1;
        private System.Windows.Forms.TextBox txtBoxSodramok1;
        private System.Windows.Forms.TextBox txtboxPajammokes1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtBoxVardas1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtboxAlgAntPop1;
        private System.Windows.Forms.TextBox txtboxvisoMokesc1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxtab1;
        private System.Windows.Forms.CheckBox checkBoxPasirkt1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox darbdMokesc;
        private System.Windows.Forms.TextBox sodrosMokes;
        private System.Windows.Forms.TextBox pajamuMokest;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox empName;
        private System.Windows.Forms.Button iseitiBtn;
        private System.Windows.Forms.Button trintiBtn;
        private System.Windows.Forms.Button skaiciuotiBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox algaiRankas;
        private System.Windows.Forms.TextBox taxdeductbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox algaAntPop;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.CheckBox checkBox22proc;
        private System.Windows.Forms.CheckBox checkBox19proc;
        private System.Windows.Forms.Label label2kokes2;
        private System.Windows.Forms.CheckBox checkBox10proc;
        private System.Windows.Forms.Label Label1mokes;
        private System.Windows.Forms.CheckBox checkBox22proc1;
        private System.Windows.Forms.CheckBox checkBox19proc1;
        private System.Windows.Forms.CheckBox checkBox10proc1;
    }
}

